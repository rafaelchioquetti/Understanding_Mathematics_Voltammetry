# E-C-
Chronoamperometric simulations of the E//C mechanism in C++ language using the GNU library for multidimensional root finding.
